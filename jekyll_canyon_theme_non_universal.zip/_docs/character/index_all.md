---
layout: page
category: index
title: Персонаж
---
## Загальна інформація
* [Alignment]({{site.baseurl}}/docs/character/alignment.html)
* [Backgrounds]({{site.baseurl}}/docs/character/backgrounds.html)
* [Fantasy-Historical Pantheons]({{site.baseurl}}/docs/character/fantasy-historical_pantheons.html)
* [Languages]({{site.baseurl}}/docs/character/languages)

## Класи
* [Варвар]({{site.baseurl}}/docs/character/classes/barbarian.html)
* [Бард]({{site.baseurl}}/docs/character/classes/bard.html)
* [Клірик]({{site.baseurl}}/docs/character/classes/cleric.html)
* [Друїд]({{site.baseurl}}/docs/character/classes/druid.html)
* [Боєць]({{site.baseurl}}/docs/character/classes/fighter.html)
* [Понах]({{site.baseurl}}/docs/character/classes/monk.html)
* [Паладин]({{site.baseurl}}/docs/character/classes/paladin.html)
* [Рейнджер]({{site.baseurl}}/docs/character/classes/ranger.html)
* [Пройдисвіт]({{site.baseurl}}/docs/character/classes/rogue.html)
* [Чародій]({{site.baseurl}}/docs/character/classes/sorcerer.html)
* [Відьмак]({{site.baseurl}}/docs/character/classes/warlock.html)
* [Чарівник]({{site.baseurl}}/docs/character/classes/wizard.html)

## Раси
* [Драконороджений]({{site.baseurl}}/docs/character/races/dragonborn.html)
* [Дворф]({{site.baseurl}}/docs/character/races/dwarf.html)
* [Ельф]({{site.baseurl}}/docs/character/races/elf.html)
* [Гном]({{site.baseurl}}/docs/character/races/gnome.html)
* [Напівельф]({{site.baseurl}}/docs/character/races/half-elf.html)
* [Напіворк]({{site.baseurl}}/docs/character/races/half-orc.html)
* [Напіврослик]({{site.baseurl}}/docs/character/races/halfling.html)
* [Людина]({{site.baseurl}}/docs/character/races/human.html)
* [Тифлінґ]({{site.baseurl}}/docs/character/races/tiefling.html)
