---
layout: page
title: Класи персонажів
---
* [Bard]({{site.baseurl}}/docs/character/classes/bard.html)
* [Cleric]({{site.baseurl}}/docs/character/classes/cleric.html)
* [Druid]({{site.baseurl}}/docs/character/classes/druid.html)
* [Fighter]({{site.baseurl}}/docs/character/classes/fighter.html)
* [Monk]({{site.baseurl}}/docs/character/classes/monk.html)
* [Paladin]({{site.baseurl}}/docs/character/classes/paladin.html)
* [Ranger]({{site.baseurl}}/docs/character/classes/ranger.html)
* [Rogue]({{site.baseurl}}/docs/character/classes/rogue.html)
* [Sorcerer]({{site.baseurl}}/docs/character/classes/sorcerer.html)
* [Warlock]({{site.baseurl}}/docs/character/classes/warlock.html)
* [Wizard]({{site.baseurl}}/docs/character/classes/wizard.html)
