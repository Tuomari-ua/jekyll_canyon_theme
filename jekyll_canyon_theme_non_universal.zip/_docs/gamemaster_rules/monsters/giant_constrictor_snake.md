---
category: monsters
layout: page
tag: 2

title: Giant Constrictor Snake 
---
_Huge beast, unaligned_

**Armor Class** 12    
**Hit Points** 60 (8d12 + 8)    
**Speed** 30 ft., swim 30 ft. 

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 19 (+4) | 14 (+2) | 12 (+1) | 1 (−5)  | 10 (+0) | 3 (−4)  |  

**Skills** Perception +2    
**Senses** blindsight 10 ft., passive Perception 12    
**Languages** --    
**Challenge** 2 (450 XP) 

### Actions    
**Bite.** _Melee Weapon Attack:_ +6 to hit, reach 10 ft., one creature. _Hit:_ 11 (2d6 + 4) piercing damage.    
**Constrict.** _Melee Weapon Attack:_ +6 to hit, reach 5 ft., one creature. _Hit:_ 13 (2d8 + 4) bludgeoning damage, and the target is grappled (escape DC 16). Until this grapple ends, the creature is restrained, and the snake can't constrict another target. 