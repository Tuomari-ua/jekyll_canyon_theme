---
category: monsters
layout: page
tag: .5

title: Black Bear 
---
_Medium beast, unaligned_

**Armor Class** 11 (natural armor)    
**Hit Points** 19 (3d8 + 6)    
**Speed** 40 ft., climb 30 ft.

| STR     | DEX     | CON     | INT     | WIS     | CHA     |
|---------|---------|---------|---------|---------|---------|
| 15 (+2) | 10 (+0) | 14 (+2) | 2 (−4)  | 12 (+1) | 7 (−2)  |    

**Skills** Perception +3    
**Senses** passive Perception 13    
**Languages** --    
**Challenge** 1/2 (100 XP) 

**Keen Smell.** The bear has advantage on Wisdom (Perception) checks that rely on smell. 

### Actions 
**Multiattack.** The bear makes two attacks: one with its bite and one with its claws.    
**Bite.** _Melee Weapon Attack:_ +3 to hit, reach 5 ft., one target. _Hit:_ 5 (1d6 + 2) piercing damage.    
**Claws.** _Melee Weapon Attack:_ +3 to hit, reach 5 ft., one target. _Hit:_ 7 (2d4 + 2) slashing damage. 