---
category: monsters
layout: page
title: Monster Indexes
---
* [Monsters by CR](/gamemaster_rules/monster_indexes/monsters_by_cr/)
* [Monsters by Name](/gamemaster_rules/monster_indexes/monsters_by_name/)
* [Monsters by Type](/gamemaster_rules/monster_indexes/monsters_by_type)
