---
layout: monsters_typelist
title: Монстри за типом
---
