---
category: items
layout: page
name: Potion of Climbing
type: potion
title: Potion of Climbing 
---
_Potion, common_ 

When you drink this potion, you gain a climbing speed equal to your walking speed for 1 hour. During this time, you have advantage on Strength (Athletics) checks you make to climb. The potion is separated into brown, silver, and gray layers resembling bands of stone. Shaking the bottle fails to mix the colors. 