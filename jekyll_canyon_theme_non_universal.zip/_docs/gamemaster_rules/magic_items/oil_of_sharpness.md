---
category: items
layout: page
name: Oil of Sharpness
type: potion
title: Oil of Sharpness 
---
_Potion, very rare_ 

This clear, gelatinous oil sparkles with tiny, ultrathin silver shards. The oil can coat one slashing or piercing weapon or up to 5 pieces of slashing or piercing ammunition. Applying the oil takes 1 minute. For 1 hour, the coated item is magical and has a +3 bonus to attack and damage rolls. 
