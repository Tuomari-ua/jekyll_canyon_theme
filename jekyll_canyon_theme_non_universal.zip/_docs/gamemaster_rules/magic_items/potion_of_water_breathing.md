---
category: items
layout: page
name: Potion of Water Breathing
type: potion
title: Potion of Water Breathing 
---
_Potion, uncommon_ 

You can breathe underwater for 1 hour after drinking this potion. Its cloudy green fluid smells of the sea and has a jellyfish-like bubble floating in it.
