---
category: items
layout: page
name: Ring of Swimming
type: ring
title: Ring of Swimming 
---
_Ring, uncommon_ 

You have a swimming speed of 40 feet while wearing this ring. 