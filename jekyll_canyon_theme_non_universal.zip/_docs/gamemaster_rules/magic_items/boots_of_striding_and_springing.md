---
category: items
layout: page
name: Boots of Striding and Springing
type: item
title: Boots of Striding and Springing 
---
_Wondrous item, uncommon (requires attunement)_ 

While you wear these boots, your walking speed becomes 30 feet, unless your walking speed is higher, and your speed isn't reduced if you are encumbered or wearing heavy armor. In addition, you can jump three times the normal distance, though you can't jump farther than your remaining movement would allow. 