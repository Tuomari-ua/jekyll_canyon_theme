---
category: items
layout: page
name: Brooch of Shielding
type: item
title: Brooch of Shielding 
---
_Wondrous item, uncommon (requires attunement)_ 

While wearing this brooch, you have resistance to force damage, and you have immunity to damage from the **_magic missile_** spell. 