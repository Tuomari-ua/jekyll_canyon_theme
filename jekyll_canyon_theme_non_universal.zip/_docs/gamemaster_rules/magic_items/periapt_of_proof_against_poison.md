---
category: items
layout: page
name: Periapt of Proof against Poison
type: item
title: Periapt of Proof against Poison 
---
_Wondrous item, rare_ 

This delicate silver chain has a brilliant-cut black gem pendant. While you wear it, poisons have no effect on you. You are immune to the poisoned condition and have immunity to poison damage. 