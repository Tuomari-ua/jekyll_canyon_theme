---
category: items
layout: page
name: Dwarven Plate
type: armor
title: Dwarven Plate 
---
_Armor (plate), very rare_ 

While wearing this armor, you gain a +2 bonus to AC. In addition, if an effect moves you against your will along the ground, you can use your reaction to reduce the distance you are moved by up to 10 feet. 
