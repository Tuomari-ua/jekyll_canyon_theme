---
category: items
layout: page
name: Shield, +1, +2, or +3
type: armor
title: Shield, +1, +2, or +3 
---
_Armor (shield), uncommon (+1), rare (+2), or very rare (+3)_ 

While holding this shield, you have a bonus to AC determined by the shield's rarity. This bonus is in addition to the shield's normal bonus to AC. 