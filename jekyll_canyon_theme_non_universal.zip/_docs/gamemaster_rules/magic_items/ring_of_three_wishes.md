---
category: items
layout: page
name: Ring of Three Wishes
type: ring
title: Ring of Three Wishes 
---
_Ring, legendary_ 

While wearing this ring, you can use an action to expend 1 of its 3 charges to cast the **_wish_** spell from it. The ring becomes nonmagical when you use the last charge. 