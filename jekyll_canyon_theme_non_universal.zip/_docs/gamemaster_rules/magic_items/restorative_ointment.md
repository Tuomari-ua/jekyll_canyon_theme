---
category: items
layout: page
name: Restorative Ointment
type: item
title: Restorative Ointment 
---
_Wondrous item, uncommon_ 

This glass jar, 3 inches in diameter, contains 1d4 + 1 doses of a thick mixture that smells faintly of aloe. The jar and its contents weigh 1/2 pound.

As an action, one dose of the ointment can be swallowed or applied to the skin. The creature that receives it regains 2d8 + 2 hit points, ceases to be poisoned, and is cured of any disease. 