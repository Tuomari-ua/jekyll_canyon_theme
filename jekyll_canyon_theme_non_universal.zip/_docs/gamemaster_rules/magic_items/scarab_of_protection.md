---
category: items
layout: page
name: Scarab of Protection
type: item
title: Scarab of Protection 
---
_Wondrous item, legendary (requires attunement)_ 

If you hold this beetle-shaped medallion in your hand for 1 round, an inscription appears on its surface revealing its magical nature. It provides two benefits while it is on your person:

* You have advantage on saving throws against spells. 
* The scarab has 12 charges. If you fail a saving throw against a necromancy spell or a harmful effect originating from an undead creature, you can use your reaction to expend 1 charge and turn the failed save into a successful one. The scarab crumbles into powder and is destroyed when its last charge is expended. 