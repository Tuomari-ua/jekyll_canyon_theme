---
category: items
layout: page
name: Arrow-Catching Shield
type: armor
title: Arrow-Catching Shield 
---
_Armor (shield), rare (requires attunement)_ 

You gain a +2 bonus to AC against ranged attacks while you wield this shield. This bonus is in addition to the shield's normal bonus to AC. In addition, whenever an attacker makes a ranged attack against a target within 5 feet of you, you can use your reaction to become the target of the attack instead. 