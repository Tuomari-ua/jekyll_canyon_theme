---
category: items
layout: page
name: Bowl of Command Water Elementals
type: item
title: Bowl of Commanding Water Elementals 
---
_Wondrous item, rare_ 

While this bowl is filled with water, you can use an action to speak the bowl's command word and summon a water elemental, as if you had cast the **_conjure elemental_** spell. The bowl can't be used this way again until the next dawn.

The bowl is about 1 foot in diameter and half as deep. It weighs 3 pounds and holds about 3 gallons. 
