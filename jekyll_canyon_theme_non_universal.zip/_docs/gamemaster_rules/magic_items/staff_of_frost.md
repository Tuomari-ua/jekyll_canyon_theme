---
category: items
layout: page
name: Staff of Frost
type: staff
title: Staff of Frost 
---
_Staff, very rare (requires attunement by a druid, sorcerer, warlock, or wizard)_ 

You have resistance to cold damage while you hold this staff.

The staff has 10 charges. While holding it, you can use an action to expend 1 or more of its charges to cast one of the following spells from it, using your spell save DC: **_cone of cold_** (5 charges), **_fog cloud_** (1 charge), **_ice storm_** (4 charges), or **_wall of ice_** (4 charges).

The staff regains 1d6 + 4 expended charges daily at dawn. If you expend the last charge, roll a d20. On a 1, the staff turns to water and is destroyed. 