---
category: items
layout: page
name: Cloak of Elvenkind
type: item
title: Cloak of Elvenkind 
---
_Wondrous item, uncommon (requires attunement)_ 

While you wear this cloak with its hood up, Wisdom (Perception) checks made to see you have disadvantage, and you have advantage on Dexterity (Stealth) checks made to hide, as the cloak's color shifts to camouflage you. Pulling the hood up or down requires an action. 