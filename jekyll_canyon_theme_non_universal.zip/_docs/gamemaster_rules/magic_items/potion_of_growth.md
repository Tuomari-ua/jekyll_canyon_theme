---
category: items
layout: page
name: Potion of Growth
type: potion
title: Potion of Growth 
---
_Potion, uncommon_ 

When you drink this potion, you gain the "enlarge" effect of the **_enlarge/reduce_** spell for 1d4 hours (no concentration required). The red in the potion's liquid continuously expands from a tiny bead to color the clear liquid around it and then contracts. Shaking the bottle fails to interrupt this process. 