---
category: items
layout: page
name: Ring of Invisibility
type: ring
title: Ring of Invisibility 
---
_Ring, legendary (requires attunement)_ 

While wearing this ring, you can turn invisible as an action. Anything you are wearing or carrying is invisible with you. You remain invisible until the ring is removed, until you attack or cast a spell, or until you use a bonus action to become visible again. 