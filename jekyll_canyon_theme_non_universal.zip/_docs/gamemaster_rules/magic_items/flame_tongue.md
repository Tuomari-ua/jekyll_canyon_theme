---
category: items
layout: page
name: Flame Tongue
type: weapon
title: Flame Tongue 
---
_Weapon (any sword), rare (requires attunement)_ 

You can use a bonus action to speak this magic sword's command word, causing flames to erupt from the blade. These flames shed bright light in a 40-foot radius and dim light for an additional 40 feet. While the sword is ablaze, it deals an extra 2d6 fire damage to any target it hits. The flames last until you use a bonus action to speak the command word again or until you drop or sheathe the sword. 