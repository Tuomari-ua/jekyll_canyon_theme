---
category: items
layout: page
name: Potion of Diminution
type: potion
title: Potion of Diminution 
---
_Potion, rare_ 

When you drink this potion, you gain the "reduce" effect of the **_enlarge/reduce_** spell for 1d4 hours (no concentration required). The red in the potion's liquid continuously contracts to a tiny bead and then expands to color the clear liquid around it. Shaking the bottle fails to interrupt this process.