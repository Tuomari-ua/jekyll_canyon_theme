---
category: items
layout: page
name: Gauntlets of Ogre Power
type: item
title: Gauntlets of Ogre Power 
---
_Wondrous item, uncommon (requires attunement)_ 

Your Strength score is 19 while you wear these gauntlets. They have no effect on you if your Strength is already 19 or higher. 