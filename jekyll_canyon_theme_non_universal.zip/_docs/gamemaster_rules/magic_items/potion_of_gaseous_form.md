---
category: items
layout: page
name: Potion of Gaseous Form
type: potion
title: Potion of Gaseous Form 
---
_Potion, rare_ 

When you drink this potion, you gain the effect of the **_gaseous form_** spell for 1 hour (no concentration required) or until you end the effect as a bonus action. This potion's container seems to hold fog that moves and pours like water.