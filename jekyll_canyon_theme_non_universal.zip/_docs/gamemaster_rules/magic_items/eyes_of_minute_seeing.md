---
category: items
layout: page
name: Eyes of Minute Seeing
type: item
title: Eyes of Minute Seeing 
---
_Wondrous item, uncommon_ 

These crystal lenses fit over the eyes. While wearing them, you can see much better than normal out to a range of 1 foot. You have advantage on Intelligence (Investigation) checks that rely on sight while searching an area or studying an object within that range.