---
category: items
layout: page
name: Giant Slayer
type: weapon
title: Giant Slayer 
---
_Weapon (any axe or sword), rare_ 

You gain a +1 bonus to attack and damage rolls made with this magic weapon.

When you hit a giant with it, the giant takes an extra 2d6 damage of the weapon's type and must succeed on a DC 15 Strength saving throw or fall prone. For the purpose of this weapon, "giant" refers to any creature with the giant type, including ettins and trolls. 