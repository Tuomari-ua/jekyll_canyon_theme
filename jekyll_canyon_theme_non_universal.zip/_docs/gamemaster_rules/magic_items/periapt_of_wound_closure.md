---
category: items
layout: page
name: Periapt of Wound Closure
type: item
title: Periapt of Wound Closure 
---
_Wondrous item, uncommon (requires attunement)_ 

While you wear this pendant, you stabilize whenever you are dying at the start of your turn. In addition, whenever you roll a Hit Die to regain hit points, double the number of hit points it restores. 