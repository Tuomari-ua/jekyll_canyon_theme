---
category: items
layout: page
name: Adamantine Armor
type: armor
title: Adamantine Armor 
---
_Armor (medium or heavy, but not hide), uncommon_ 

This suit of armor is reinforced with adamantine, one of the hardest substances in existence. While you're wearing it, any critical hit against you becomes a normal hit. 
