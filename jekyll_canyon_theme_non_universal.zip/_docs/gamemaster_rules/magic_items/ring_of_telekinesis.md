---
category: items
layout: page
name: Ring of Telekinesis
type: ring
title: Ring of Telekinesis 
---
_Ring, very rare (requires attunement)_ 

While wearing this ring, you can cast the **_telekinesis_** spell at will, but you can target only objects that aren't being worn or carried. 